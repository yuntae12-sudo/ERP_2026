int32 objNum
lane[] lane_data